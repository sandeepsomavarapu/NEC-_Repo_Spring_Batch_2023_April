package com.nec.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan("com.nec.springcore")
public class Client {

	public static void main(String[] args) {

//		Resource resource = new ClassPathResource("springconfig.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);

		ApplicationContext factory = new AnnotationConfigApplicationContext(Client.class);

		Employee emp = factory.getBean("emp", Employee.class);
		System.out.println(emp);

		Employee emp1 = factory.getBean("emp", Employee.class);
		System.out.println(emp1);

		//spring bean scope-->singleton,prototype
		

	System.out.println(emp.getAddress());

	}

}
