
package com.pdw.entities;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestClient {
public static void main(String[] args) {
	
	EntityManagerFactory factory = Persistence
			.createEntityManagerFactory("many-many");
	EntityManager em = factory.createEntityManager();
	em.getTransaction().begin();
	
	Categories c1 = new Categories();
	c1.setCategoryId(1);
	c1.setCategoryName("cat 1");

	Categories c2=new Categories();
	c2.setCategoryId(2);
	c2.setCategoryName("cat 2");

	Item i1=new Item();
	Item i2 = new Item();

	i1.setItemId(101);
	i1.setItemName("item1");

	i2.setItemId(102);
	i2.setItemName("item2");

	Set  s =new HashSet();
	s.add(i1);
	s.add(i2);

	c1.setItems(s);
	c2.setItems(s);

	em.persist(c1);
	em.persist(c2);

 	em.getTransaction().commit();
	em.close();
	factory.close();
	
	
}
}
