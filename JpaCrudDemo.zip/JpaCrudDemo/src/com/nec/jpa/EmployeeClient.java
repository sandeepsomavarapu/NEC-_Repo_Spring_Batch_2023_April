package com.nec.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EmployeeClient {
	public static void main(String[] args) {

		EntityManagerFactory entityManagerFacotry = Persistence.createEntityManagerFactory("mysql");
		EntityManager entityManager = entityManagerFacotry.createEntityManager();

		// crud --->insert-->persist(),merge,remove,find
		entityManager.getTransaction().begin();
		// Employee emp = new Employee(124, "mahesh", 9000, "trainer");

		// entityManager.persist(emp);

		Employee emp = entityManager.find(Employee.class, 124);

		System.out.println(emp);

//		emp.setEmpName("sandeep");
//		emp.setEmpSal(20000);
//		entityManager.merge(emp);// ORM
		
		entityManager.remove(emp);

		entityManager.getTransaction().commit();
		System.out.println("Data Inserted");

	}
}
