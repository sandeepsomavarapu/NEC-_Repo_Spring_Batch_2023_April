package com.nec.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {

//		Resource resource = new ClassPathResource("springconfig.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);

		ApplicationContext factory = new ClassPathXmlApplicationContext("springconfig.xml");

		Employee emp = factory.getBean("emp", Employee.class);
		System.out.println(emp);

		Employee emp1 = factory.getBean("emp", Employee.class);
		System.out.println(emp1);

		//spring bean scope-->singleton,prototype
		

	System.out.println(emp.getAddress());

	}

}
