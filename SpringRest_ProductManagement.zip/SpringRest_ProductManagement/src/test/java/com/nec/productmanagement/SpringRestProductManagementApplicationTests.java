package com.nec.productmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestProductManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
