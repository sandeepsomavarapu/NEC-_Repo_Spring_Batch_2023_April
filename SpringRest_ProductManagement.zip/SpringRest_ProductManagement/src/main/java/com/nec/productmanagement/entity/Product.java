package com.nec.productmanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "nec_products_info")
public class Product {
	@Id
	@Column(name = "pid", length = 20)
	@Min( message="productid can't -ve number ",value=1)
	private int productId;
	@NotEmpty(message = "product name can't be empty or null")
	@Size(min = 5, max = 12, message = "product name length must be in the range ...")
	private String productName;
	@Min( message="product price can't -ve price ",value=1)
	@Max( message="product price can't be greater than 15000 ",value=15000)
	private int productPrice;
	@NotNull(message = "product category cant be null...")
	private String productCategory;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productName, int productPrice, String productCategory) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
	}

}
