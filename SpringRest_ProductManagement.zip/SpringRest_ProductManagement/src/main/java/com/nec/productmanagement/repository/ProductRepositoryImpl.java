package com.nec.productmanagement.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.nec.productmanagement.entity.Product;
import com.nec.productmanagement.exceptions.ProductIdNotFound;

@Repository
public class ProductRepositoryImpl implements ProductRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Inserted Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		entityManager.merge(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		Product product=getProduct(productId);
		if(product!=null)
		{
			entityManager.remove(product);
			return "Product Deleted Successfully";
		}
		else
		{
			throw new ProductIdNotFound("Enter Valid ProductId......");
		}
		
	}

	@Override
	public Product getProduct(int productId) {
		Product product= entityManager.find(Product.class, productId);
		if(product!=null)
		{
		return product;
		}
		else
		{
			throw new ProductIdNotFound("Enter Valid ProductId......");
		}
		
	}

	@Override
	public List<Product> getAllProducts() {

		TypedQuery<Product> products = entityManager.createQuery("select p from Product p", Product.class);

		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsInbetweenPrices(int intialPrice, int finalPrice) {
		TypedQuery<Product> products = entityManager
				.createQuery("select p from Product p where p.productPrice between ?1 and ?2", Product.class);
		products.setParameter(1, intialPrice);
		products.setParameter(2, finalPrice);
		return products.getResultList();
	}

	@Override
	public List<Product> GetAllProductsByCategory(String category) {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p where p.productCategory=?1",
				Product.class);
		products.setParameter(1, category);
		return products.getResultList();
	}

}
