package com.nec.productmanagement.exceptions;

public class ProductIdNotFound extends RuntimeException {

	public ProductIdNotFound(String message) {
		super(message);
	}
}
