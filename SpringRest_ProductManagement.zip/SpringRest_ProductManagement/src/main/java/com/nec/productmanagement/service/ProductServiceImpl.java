package com.nec.productmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.productmanagement.entity.Product;
import com.nec.productmanagement.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository dao;

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {

		return dao.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {

		return dao.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return dao.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return dao.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsInbetweenPrices(int intialPrice, int finalPrice) {

		return dao.getAllProductsInbetweenPrices(intialPrice, finalPrice);
	}

	@Override
	public List<Product> GetAllProductsByCategory(String category) {

		return dao.GetAllProductsByCategory(category);
	}

}
