package com.cg.jpacrud.client;

import java.util.List;
import java.util.Scanner;

import com.cg.jpacrud.entities.Employee;
import com.cg.jpacrud.service.EmployeeService;
import com.cg.jpacrud.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {
		// UI<--->service<--->dao-->DB
		// Debug this program as Debug -> Debug as Java Application
			
		EmployeeService service = new EmployeeServiceImpl();// object injection
		Scanner scanner = new Scanner(System.in);
		Employee emp = null;
		String result = null;
		while (true) {
			System.out.println("Employee Management Application");
			System.out.println("***********************");
			System.out.println("Choose One Option");
			System.out.println(
					"1.Add Employee \n2.Select Employee \n3.Update Employee \n4.Delete Employee \n5.Get All Employees");
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Your EmpNum");
				int empId = scanner.nextInt();
				System.out.println("Enter Your Name");
				String empName = scanner.next();
				System.out.println("Enter Your Salary");
				int empSal = scanner.nextInt();
				System.out.println("Enter Your Address");
				String empAdd = scanner.next();

				emp = new Employee(empId, empName, empSal, empAdd);
				result = service.addEmployee(emp);
				System.out.println(result);
				break;
			case 2:
				System.out.println("Enter EmpId");
				int empId1 = scanner.nextInt();
				Employee employee = service.findEmployeeById(empId1);
				System.out.println(employee);
				break;
			case 3:
				System.out.println("Enter Your EmpNum");
				empId = scanner.nextInt();
				System.out.println("Enter Your Name");
				empName = scanner.next();
				System.out.println("Enter Your Salary");
				empSal = scanner.nextInt();
				System.out.println("Enter Your Address");
				empAdd = scanner.next();

				emp = new Employee(empId, empName, empSal, empAdd);
				result = service.updateEmployee(emp);
				System.out.println(result);
				break;
			case 4:
				System.out.println("Enter EmpId");
				empId1 = scanner.nextInt();
				result = service.removeEmployee(service.findEmployeeById(empId1));
				System.out.println(result);
				break;
			case 5:
				List<Employee> empsResult = service.getAllEmployee();
				for(Employee emp1 :empsResult)
				{
					System.out.println(emp1);
				}
				//empsResult.forEach(System.out::println);
				break;
			}
		}
	}
}
