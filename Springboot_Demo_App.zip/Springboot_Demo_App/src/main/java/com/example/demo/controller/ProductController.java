package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Product;

@RestController
@RequestMapping("/product") // http://localhost:9911/product
public class ProductController {
	@GetMapping("/getProducts") // http://localhost:9911/product/getProducts
	public List<Product> getProducts() {
		ArrayList<Product> products = new ArrayList<>();

		products.add(new Product(111, "samsung", 20000, "electronics"));
		products.add(new Product(121, "lg", 25000, "electronics"));
		products.add(new Product(511, "dell", 32000, "electronics"));
		products.add(new Product(10, "lenovo", 45000, "electronics"));

		return products;

	}

	@GetMapping("/getProduct/{pid}") // http://localhost:9911/product/getProduct/111
	public Product getProduct(@PathVariable("pid") int productId) {
		ArrayList<Product> products = new ArrayList<>();

		products.add(new Product(111, "samsung", 20000, "electronics"));
		products.add(new Product(121, "lg", 25000, "electronics"));
		products.add(new Product(511, "dell", 32000, "electronics"));
		products.add(new Product(10, "lenovo", 45000, "electronics"));
		Product pro = null;
		for (Product product : products) {
			if (product.getProductId() == productId)
				pro = product;
		}
		return pro;
	}
}
