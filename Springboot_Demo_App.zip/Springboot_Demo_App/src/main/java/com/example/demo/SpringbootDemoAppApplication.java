package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDemoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDemoAppApplication.class, args);
	}

}
//@Configuration @ComponentScan @EnableAutoConfiguration